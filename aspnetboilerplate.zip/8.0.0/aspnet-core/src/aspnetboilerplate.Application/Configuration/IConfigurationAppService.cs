﻿using System.Threading.Tasks;
using aspnetboilerplate.Configuration.Dto;

namespace aspnetboilerplate.Configuration
{
    public interface IConfigurationAppService
    {
        Task ChangeUiTheme(ChangeUiThemeInput input);
    }
}
