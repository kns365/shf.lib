﻿using aspnetboilerplate.Debugging;

namespace aspnetboilerplate
{
    public class aspnetboilerplateConsts
    {
        public const string LocalizationSourceName = "aspnetboilerplate";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;


        /// <summary>
        /// Default pass phrase for SimpleStringCipher decrypt/encrypt operations
        /// </summary>
        public static readonly string DefaultPassPhrase =
            DebugHelper.IsDebug ? "gsKxGZ012HLL3MI5" : "5badb67ff5374718b9abf6d59ae635e4";
    }
}
