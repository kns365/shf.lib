﻿using Microsoft.EntityFrameworkCore;
using Abp.Zero.EntityFrameworkCore;
using aspnetboilerplate.Authorization.Roles;
using aspnetboilerplate.Authorization.Users;
using aspnetboilerplate.MultiTenancy;

namespace aspnetboilerplate.EntityFrameworkCore
{
    public class aspnetboilerplateDbContext : AbpZeroDbContext<Tenant, Role, User, aspnetboilerplateDbContext>
    {
        /* Define a DbSet for each entity of the application */
        
        public aspnetboilerplateDbContext(DbContextOptions<aspnetboilerplateDbContext> options)
            : base(options)
        {
        }
    }
}
